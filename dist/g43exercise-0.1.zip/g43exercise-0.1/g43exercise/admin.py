from django.contrib import admin
from g43exercise.models import Article

# Register your models here.
admin.site.register(Article)